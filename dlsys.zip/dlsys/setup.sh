#!/bin/bash
sudo apt-get install libopenblas-dev
